using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    [Range(0, 0.25f)]
    //[SerializeField] // Sirve para visualizar un campo en unity
    public float velocidad;
    SpriteRenderer sr;
    Vector3 size;
    Vector2 sizePixels;
    // Start is called before the first frame update
    void Start()
    {
        Debug.Log($" Mi posición es: {transform.position}");

        size = transform.localScale;
        sizePixels = Camera.main.WorldToScreenPoint(size);
        sizePixels.x = sizePixels.x - Screen.width/2;
        sizePixels.y = sizePixels.y - Screen.height/2;

        print(sizePixels.x + " --> " + sizePixels.y);
    }

    // Update is called once per frame
    void Update()
    {

      
        //Vector3 aux = transform.position;
        //transform.position = aux + Vector3.right;

        Color c = new Color(Random.Range(0, 1f), Random.Range(0, 1f), Random.Range(0, 1f));

        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 direction = new Vector3(horizontal, vertical, 0);

        transform.position += direction * velocidad;

        bool spacePressed = Input.GetKeyDown("space");

        if (spacePressed)
        {
            sr.color = c;
        }

        Vector3 posicionWorld = Camera.main.WorldToScreenPoint(transform.position);

        if (posicionWorld.y > Screen.height-sizePixels.y/2)
        {
            posicionWorld.y = Screen.height-sizePixels.y/2;
        }

        if (posicionWorld.y < 0+sizePixels.y/2)
        {
            posicionWorld.y = 0+sizePixels.y/2;
        }

        if (posicionWorld.x > Screen.width-sizePixels.x/2)
        {
            posicionWorld.x = Screen.width-sizePixels.x/2;
        }

        if (posicionWorld.x < 0+sizePixels.x/2)
        {
            posicionWorld.x = 0+sizePixels.x/2;
        }

        transform.position = Camera.main.ScreenToWorldPoint(posicionWorld);


    }
}
