using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Center : MonoBehaviour
{
    [Range(0, 0.005f)]
    [SerializeField]
    float velocidad;
    Vector3 direction;
    // Start is called before the first frame update
    void Start()
    {
        direction = Vector3.zero - transform.position;
    }

    // Update is called once per frame
    void Update()
    {

        transform.position += direction * velocidad;

        Vector3 posicionWorld = Camera.main.WorldToScreenPoint(transform.position);

        if (posicionWorld.y > Screen.height || posicionWorld.y < 0 || posicionWorld.x > Screen.width || posicionWorld.x < 0)
        {
            Destroy(gameObject);
            Debug.Log("Destroy : " + posicionWorld.y + "  " + posicionWorld.x);
        }
    }
}
