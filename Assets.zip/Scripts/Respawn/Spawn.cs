using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    [SerializeField]
    GameObject enemy;
    [SerializeField]
    float timer = 0, interval = 200f;


    Vector2 random;

    // Start is called before the first frame update
    void Start()
    {

        Debug.Log($"Width: {Screen.width}, Height: {Screen.height}");
    }

    // Update is called once per frame
    void Update()
    {
        bool spacePressed = Input.GetKeyDown("space");

        timer += Time.deltaTime;
        if (timer >= interval)
        {
            SpawnObject();
            timer = 0;
        }

        if (spacePressed)
        {
            SpawnObject();

        }


    }

    void SpawnObject()
    {
        int x = Random.Range(0, Screen.width);
        int y = Random.Range(0, Screen.height);
        //int side = Random.Range(1, 4);
        int side = Random.Range(0, 4);

        // Vector3 v = new Vector3(x, y, 0);

        // Vector2 p = Camera.main.ScreenToWorldPoint(v);

        random = new Vector2(x, y);

        /* if (side == 1)
        {
            random = new Vector2(0, y);
        }
        else if (side == 3)
        {
            random = new Vector2(Screen.width, y);
        }
        else if (side == 2)
        {
            random = new Vector2(x, Screen.height);
        }
        else if (side == 4)
        {
            random = new Vector2(x, 0);
        } */

        /*    switch (side)
           {
               case 1:
                   random = new Vector2(0, y);
                   break;
               case 2:
                   random = new Vector2(x, Screen.height);
                   break;
               case 3:
                   random = new Vector2(Screen.width, y);
                   break;
               case 4:
                   random = new Vector2(x, 0);
                   break;
           } */

        switch (side)
        {
            case 0:
                random = new Vector2(random.x, 0);
                break;
            case 1:
                random = new Vector2(random.x, Screen.height);
                break;
            case 2:
                random = new Vector2(0, random.y);
                break;
            case 3:
                random = new Vector2(Screen.width, random.y);
                break;
        }

        random = Camera.main.ScreenToWorldPoint(random);

        Instantiate(enemy, (Vector3)random, Quaternion.identity);




        /* 

            // Al pulsar espacio cambio de color aleatoriamente

        //Instantiate(circle, Vector3.zero, Quaternion.identity); // Vector3.zero es igual a new Vector3(0,0,0)

        //float horizontal = Random.Range(0,1f);
        //float vertical = Random.Range(0,1f);

        float horizontal = Random.Range(0, Screen.width);
        float vertical = Random.Range(0, Screen.height);

        Vector3 direction = new Vector3(horizontal, vertical, 0);

        circle.transform.position = direction; */
    }
}
