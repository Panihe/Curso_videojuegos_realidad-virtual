using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Machine : MonoBehaviour
{
    [Range(0, 25f)]
    [SerializeField]
    float velocidad;

    /* Example Get, Set


    private int _level;

    public int Level {
        get { return _level; }

        private set 
        {
            if(value > 0) {
                _level = value;
            }

            LoadLevel();
            Resetpuntuation();
            _level = value;
        }
    } */

    /*    private int vel;

       public void SetVelocity(int v) {
           if(v > 0)
               vel= v;
           Level += 1;
       }
    */

    Vector3 size;
    Vector3 size2;
    Vector2 sizePixels;
    Vector2 size2Pixels;

    [SerializeField]
    private GameObject Ball;

    // Start is called before the first frame update
    void Start()
    {
        size = transform.localScale;
        sizePixels = Camera.main.WorldToScreenPoint(size);
        sizePixels.y = sizePixels.y - Screen.height / 2;
        size2 = GameObject.Find("Wallup").transform.localScale;
        size2Pixels = Camera.main.WorldToScreenPoint(size2);
        size2Pixels.y = size2Pixels.y - Screen.height / 2;
    }

    // Update is called once per frame
    void Update()
    {
        /* float vertical = Input.GetAxis("Vertical2");

        Vector3 direction = new Vector3(0, vertical, 0);
        
        transform.position += direction * velocidad; 

        bool upArrowPressed = Input.GetKeyDown(KeyCode.UpArrow);
        bool downArrowPressed = Input.GetKeyDown(KeyCode.DownArrow);

        Vector3 posicionWorld = Camera.main.WorldToScreenPoint(transform.position);

        if (posicionWorld.y > Screen.height-sizePixels.y/2 - size2Pixels.y/2)
        {
            posicionWorld.y = Screen.height-sizePixels.y/2 - size2Pixels.y/2;
        }

        if (posicionWorld.y < 0+sizePixels.y/2 + size2Pixels.y/2)
        {
            posicionWorld.y = 0+sizePixels.y/2 + size2Pixels.y/2;
        }

        transform.position = Camera.main.ScreenToWorldPoint(posicionWorld); */

        if (transform.position.y > Ball.transform.position.y)
        {
            Vector3 direction = new Vector3(0, -1, 0);

            transform.position += direction * Time.deltaTime * velocidad;

        }
        else if (transform.position.y < Ball.transform.position.y)
        {
            Vector3 direction = new Vector3(0, 1, 0);

            transform.position += direction * Time.deltaTime * velocidad;
        }
    }
}
