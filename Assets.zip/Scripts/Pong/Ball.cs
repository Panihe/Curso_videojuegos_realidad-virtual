using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    Rigidbody2D rb2d;
    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        ImpulseBall();
    }

    // Update is called once per frame
    void Update()
    {
        int x = Random.Range(0, Screen.width);
        int y = Random.Range(0, Screen.height);

        int side = Random.Range(0, 4);
        Vector2 random = new Vector2(x, y);

         switch (side)
        {
            case 0:
                random = new Vector2(random.x, 0);
                break;
            case 1:
                random = new Vector2(random.x, Screen.height);
                break;
            case 2:
                random = new Vector2(0, random.y);
                break;
            case 3:
                random = new Vector2(Screen.width, random.y);
                break;
        }

        random = Camera.main.ScreenToWorldPoint(random);
        
    }

    public void ImpulseBall() {

        Vector3 direction = new Vector3(Random.Range(5, 10f), Random.Range(5, 10f), Random.Range(0, 5f));
        rb2d.AddForce(direction, ForceMode2D.Impulse);
    }

    public void PosicionarBola() {
        transform.position=Vector3.zero;
        rb2d.velocity=Vector2.zero;
    }
}
