using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static int pointsPlayer;
    public static int pointsMachine;

    float timer = 0, interval = 300f;
    float timerMin, timerSec;
    string  mensajeGanador;
    // Start is called before the first frame update

    GameObject reiniciar;

    void Start()
    {
        GameManager.pointsPlayer = 0;
        GameManager.pointsMachine = 0;
        Time.timeScale = 1;
        mensajeGanador = "";
        reiniciar = GameObject.FindWithTag("Reiniciar");
        reiniciar.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {

        timer += Time.deltaTime;
        float timerRes = interval - timer;
        if (timerRes<0) timerRes = 0;
        timerMin = (timerRes) / 60;
        timerSec = (timerRes) % 60;   
        if (timer >= interval)
        {
            if (pointsPlayer > pointsMachine)
            {
                mensajeGanador = "Ganador: Player";
                GameObject.FindWithTag("Mensaje_Ganador").GetComponent<Text>().text = mensajeGanador;
            }
            else if (pointsPlayer < pointsMachine)
            {
                mensajeGanador = "Ganador: Machine";
                GameObject.FindWithTag("Mensaje_Ganador").GetComponent<Text>().text = mensajeGanador;
            }
            else
            {
                mensajeGanador = "Empate";
                GameObject.FindWithTag("Mensaje_Ganador").GetComponent<Text>().text = mensajeGanador;
            }

            stopGame();
        }
        endGame();
    }

    void endGame()
    {
        GameObject.FindWithTag("Marcador_player1").GetComponent<Text>().text = pointsPlayer.ToString();
        GameObject.FindWithTag("Marcador_player2").GetComponent<Text>().text = pointsMachine.ToString();
        GameObject.FindWithTag("Time_Game").GetComponent<Text>().text = Mathf.Floor(timerMin) + " : " + Mathf.Floor(timerSec);

        if (pointsPlayer == 10 || pointsMachine == 10)
        {
            stopGame();
        }

        if (pointsPlayer == 10)
        {
            mensajeGanador = "Ganador: Player";
            GameObject.FindWithTag("Mensaje_Ganador").GetComponent<Text>().text = mensajeGanador;
        }

        if (pointsMachine == 10)
        {
            mensajeGanador = "Ganador: Machine";
            GameObject.FindWithTag("Mensaje_Ganador").GetComponent<Text>().text = mensajeGanador;
        }
    }

    void stopGame()
    {
        Time.timeScale = 0;
        reiniciar.SetActive(true);
    }

    public void reset()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
