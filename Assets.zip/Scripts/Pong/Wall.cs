using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wall : MonoBehaviour
{
    [SerializeField]
    GameObject ball;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionEnter2D(Collision2D col)
    {
        if(gameObject.name == "Wallleft" ) {
            GameManager.pointsMachine++;
        }

         if(gameObject.name == "Wallright" ) {
            GameManager.pointsPlayer++;
        }

        Ball bola = GameObject.Find("Ball").GetComponent<Ball>();
        bola.PosicionarBola();
        bola.ImpulseBall();
        
    }
}
