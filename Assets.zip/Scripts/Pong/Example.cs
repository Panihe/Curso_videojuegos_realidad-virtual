using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Example : MonoBehaviour
{
    //Vector3 target = new Vector3(0, 0, 0);
    // Start is called before the first frame update
    void Start()
    {
        // InvokeRepeating(nameof(SayHi), 0, 2);
        //StartCoroutine(SayHi());
        //StartCoroutine(nameof(SaludaCoroutine));
        //StartCoroutine(GoTo(target));
        Coroutine c = StartCoroutine(TimerCoroutine());
        StopCoroutine(c);
    }

    // Update is called once per frame
   /*  void Update()
    {
        Vector3 dir = target - transform.position;
        transform.position += dir * Time.deltaTime;

        if(dir.magnitude < 0.1) {
            print("Ha llegado");
        }
    } */

    /*   void SayHi() {
          print("Hello");
      } */

   /*  IEnumerator SaludaCoroutine()
    {
        //while (isActiveAndEnabled) // = while(true) {}
        while(isActiveAndEnabled) {
           

           yield return new WaitForSeconds(.1f);

           //yield return null; // = Update();
        }  
    } */

 /*    IEnumerator GoTo(Vector3 v) {
        Vector3 dir = target - transform.position;

        while(dir.magnitude >= 0.1) {
            transform.position += dir * Time.deltaTime; 

            

            yield return null;
        }

        print("Ha llegado");

    } */

    [SerializeField]
    int maxTime;
    IEnumerator TimerCoroutine() 
    {
        Text textDisplay = FindObjectOfType<Text>();

        for (int i = maxTime; i >= 0; i--) {

            textDisplay.text = i.ToString();

            yield return new WaitForSeconds(1f);
        }

        //Call reset() function

    }




}
