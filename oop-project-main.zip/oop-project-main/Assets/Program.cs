using System;

namespace OOPProject
{

	public class Program
	{

		public static void Main(string[] args) {


			Console.Log("Punto de entrada del programa");



		}
	}
}
